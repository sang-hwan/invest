import os
import time
import json
import requests
from dotenv import load_dotenv

load_dotenv()

import pyupbit
from openai import OpenAI
from ta.volatility import BollingerBands
from ta.momentum import RSIIndicator
from ta.trend import MACD, SMAIndicator, EMAIndicator
from ta.utils import dropna

from youtube_transcript_api import YouTubeTranscriptApi

# -----------------------------------------
# MockUpbit: 실제 Upbit 주문 API를 호출하지 않고 테스트용 더미 값 반환
# -----------------------------------------
class MockUpbit:
    def __init__(self, access_key, secret_key):
        self.access_key = access_key
        self.secret_key = secret_key

    def get_balance(self, ticker="KRW"):
        # 실제로는 요청하지 않고, 더미 값 반환
        if ticker == "KRW":
            return 100000  # 가상의 KRW 잔고
        else:
            return 100  # 가상의 코인 잔고

    def get_balances(self):
        # 잔고 리스트도 더미로
        return [
            {"currency": "KRW", "balance": "100000"},
            {"currency": "XRP", "balance": "100"},
        ]

    def buy_market_order(self, ticker, amount):
        # 주문 기능은 실제 요청 대신 로그만
        print(f"[Mock] Buy market order: {ticker}, amount: {amount}")
        return {"mock_buy_result": True}

    def sell_market_order(self, ticker, volume):
        # 주문 기능은 실제 요청 대신 로그만
        print(f"[Mock] Sell market order: {ticker}, volume: {volume}")
        return {"mock_sell_result": True}


# -----------------------------------------
# 환경 변수에서 키 불러오기
# -----------------------------------------
UPBIT_ACCESS_KEY = os.getenv("UPBIT_ACCESS_KEY")
UPBIT_SECRET_KEY = os.getenv("UPBIT_SECRET_KEY")

# 여기서 실제 Upbit 객체 대신 MockUpbit를 생성
mock_upbit = MockUpbit(UPBIT_ACCESS_KEY, UPBIT_SECRET_KEY)

client = OpenAI()  # 원본 코드대로라면 이렇게 사용했을 거라고 가정

# -----------------------------------------
# 유틸 함수들
# -----------------------------------------
def get_transcript_text_as_one_string(video_id: str) -> str:
    """YouTube 영상의 자막을 하나의 긴 문자열로 합쳐 반환"""
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
    except Exception as e:
        print(f"Error while fetching YouTube transcript: {e}")
        return ""

    combined_text = ""
    for line in transcript:
        combined_text += line["text"] + "\n"
    return combined_text


def apply_ta_indicators(df,
                        bb_window=20, bb_window_dev=2,
                        rsi_window=14,
                        macd_slow=26, macd_fast=12, macd_sign=9,
                        sma_short=5, sma_long=20,
                        ema_short=5, ema_long=20):
    """BollingerBands, RSI, MACD, SMA, EMA 지표를 DataFrame에 계산/추가"""
    df = df.rename(columns={
        "open": "Open",
        "high": "High",
        "low": "Low",
        "close": "Close",
        "volume": "Volume"
    })
    df = dropna(df)

    # Bollinger Bands
    bb = BollingerBands(close=df["Close"], window=bb_window, window_dev=bb_window_dev)
    df["bb_bbm"] = bb.bollinger_mavg()
    df["bb_bbh"] = bb.bollinger_hband()
    df["bb_bbl"] = bb.bollinger_lband()

    # RSI
    rsi = RSIIndicator(close=df["Close"], window=rsi_window)
    df["rsi"] = rsi.rsi()

    # MACD
    macd = MACD(close=df["Close"], window_slow=macd_slow, window_fast=macd_fast, window_sign=macd_sign)
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    df["macd_diff"] = macd.macd_diff()

    # SMA
    sma_ind_short = SMAIndicator(close=df["Close"], window=sma_short)
    sma_ind_long  = SMAIndicator(close=df["Close"], window=sma_long)
    df["sma_short"] = sma_ind_short.sma_indicator()
    df["sma_long"]  = sma_ind_long.sma_indicator()

    # EMA
    ema_ind_short = EMAIndicator(close=df["Close"], window=ema_short)
    ema_ind_long  = EMAIndicator(close=df["Close"], window=ema_long)
    df["ema_short"] = ema_ind_short.ema_indicator()
    df["ema_long"]  = ema_ind_long.ema_indicator()

    return df


def get_fear_and_greed_index(limit=1):
    """alternative.me의 공포-탐욕 지수를 가져오는 함수"""
    base_url = "https://api.alternative.me/fng/"
    params = {"limit": limit}
    try:
        response = requests.get(base_url, params=params, timeout=5)
        if response.status_code == 200:
            return response.json()
        else:
            print("Fear and Greed API Error:", response.status_code)
            return None
    except Exception as e:
        print("Fear and Greed API Exception:", e)
        return None


def get_latest_news_headlines(query="XRP",
                              country="us",
                              language="en",
                              api_key=os.getenv("SERP_API_KEY")):
    """SerpApi를 통해 최신 XRP 관련 뉴스를 가져오는 함수"""
    base_url = "https://serpapi.com/search.json"
    params = {
        "engine": "google_news",
        "gl": country,
        "hl": language,
        "q": query,
        "api_key": api_key,
    }
    try:
        response = requests.get(base_url, params=params, timeout=5)
        if response.status_code == 200:
            data = response.json()
            news_results = data.get("news_results", [])
            simplified_results = []
            for article in news_results:
                item = {
                    "title": article.get("title"),
                    "date": article.get("date")
                }
                simplified_results.append(item)
            return simplified_results
        else:
            print("SerpApi Error:", response.status_code)
            return []
    except Exception as e:
        print("Exception while fetching news:", e)
        return []


# -----------------------------------------
# 메인 함수
# -----------------------------------------
def ai_trading():
    """
    1) 시장 데이터 수집
    2) 지표 계산
    3) 공포탐욕 / 뉴스 / 유튜브 자막 등 수집
    4) AI에게 JSON 스키마로 의사결정 요청
    5) 매매 로직 실행 (실제 주문 부분만 MockUpbit 사용)
    """

    # A. 시장 데이터 수집
    df_daily = pyupbit.get_ohlcv("KRW-XRP", count=30, interval="day")
    df_hourly = pyupbit.get_ohlcv("KRW-XRP", count=24, interval="minute60")
    orderbook = pyupbit.get_orderbook("KRW-XRP")

    # MockUpbit로부터 잔고 조회
    krw_balance = mock_upbit.get_balance("KRW")
    xrp_balance = mock_upbit.get_balance("KRW-XRP")
    balances_info = mock_upbit.get_balances()

    # B. 보조지표 계산
    df_daily = apply_ta_indicators(df_daily)
    df_hourly = apply_ta_indicators(df_hourly)

    # C. 공포-탐욕 지수
    fng_data = get_fear_and_greed_index(limit=1)
    fng_value = None
    fng_classification = None
    if fng_data and "data" in fng_data and len(fng_data["data"]) > 0:
        fng_value = fng_data["data"][0].get("value")
        fng_classification = fng_data["data"][0].get("value_classification")

    # D. 최신 뉴스
    serpapi_key = os.getenv("SERP_API_KEY", "")
    news_headlines = get_latest_news_headlines(
        query="xrp",
        country="us",
        language="en",
        api_key=serpapi_key
    )

    # E. 유튜브 자막
    video_id = "rf_EQvubKlk"
    transcript_text = get_transcript_text_as_one_string(video_id)

    # F. AI에게 전달할 전체 데이터
    df_daily_json = df_daily.reset_index().to_json(orient="records")
    df_hourly_json = df_hourly.reset_index().to_json(orient="records")
    fear_greed_info = {
        "value": fng_value,
        "classification": fng_classification
    }
    all_data_dict = {
        "balances": {
            "krw_balance": krw_balance,
            "xrp_balance": xrp_balance,
            "balances_info": balances_info
        },
        "orderbook": orderbook,
        "ohlcv_daily_30": json.loads(df_daily_json),
        "ohlcv_hourly_24": json.loads(df_hourly_json),
        "fear_and_greed_index": fear_greed_info,
        "latest_news_headlines": news_headlines,
        "youtube_transcript": transcript_text
    }
    all_data_str = json.dumps(all_data_dict, ensure_ascii=False)

    # -----------------------------------------
    # G. ChatCompletion (json_schema 방식)
    # -----------------------------------------
    response = client.chat.completions.create(
        model="gpt-4o",  # 예시 모델명, 실제 사용 가능 여부 확인 필요
        messages=[
            {
                "role": "system",
                "content": (
                    "You're an XRP investing expert. "
                    "Analyze the provided data (balances, orderbook, "
                    "30-day daily candles, 24-hour hourly candles, TA indicators, "
                    "the Fear and Greed Index, the latest news headlines, "
                    "and the YouTube transcript) "
                    "and decide whether to BUY, SELL, or HOLD right now. "
                    "Respond ONLY in JSON format with keys: decision, reason."
                )
            },
            {
                "role": "user",
                "content": all_data_str
            }
        ],
        response_format={
            "type": "json_schema",
            "json_schema": {
                "name": "xrp_trading_decision",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {
                        "decision": {
                            "type": "string",
                            "enum": ["buy", "sell", "hold"],
                            "description": "The trading decision based on the provided data."
                        },
                        "reason": {
                            "type": "string",
                            "description": "The reason behind the trading decision."
                        }
                    },
                    "required": ["decision", "reason"],
                    "additionalProperties": False
                }
            }
        },
        temperature=1,
        max_completion_tokens=16383,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )

    # H. 응답 처리
    message_obj = response.choices[0].message
    content_str = message_obj.content

    # I. JSON 파싱
    try:
        ai_data = json.loads(content_str)
        decision = ai_data.get("decision", "")
        reason = ai_data.get("reason", "")
        print("decision:", decision, "reason:", reason)

        # J. 자동매매 로직 (MockUpbit 사용)
        if decision == "buy":
            my_krw = mock_upbit.get_balance("KRW")
            fee_based = float(my_krw) * 0.9995
            if fee_based > 5000:
                print("### Buy Order Executed ###")
                buy_result = mock_upbit.buy_market_order("KRW-XRP", fee_based)
                print(buy_result)
            else:
                print("### Buy Order Failed: Insufficient KRW ###")

        elif decision == "sell":
            my_xrp = mock_upbit.get_balance("KRW-XRP")
            my_xrp = float(my_xrp) if my_xrp else 0.0

            current_price = pyupbit.get_orderbook("KRW-XRP")[0]["orderbook_units"][0]["ask_price"]
            my_xrp_value = my_xrp * current_price
            if my_xrp_value > 5000:
                print("### Sell Order Executed ###")
                sell_result = mock_upbit.sell_market_order("KRW-XRP", my_xrp)
                print(sell_result)
            else:
                print("### Sell Order Failed: Insufficient XRP ###")

        elif decision == "hold":
            print("### Hold Position ###")
        else:
            print("### AI 응답에 지정되지 않은 의사결정(decision)입니다. ###")
            
    except json.JSONDecodeError as e:
        print("JSON 파싱 실패:", e)
        print("Raw content:", content_str)


if __name__ == "__main__":
    while True:
        ai_trading()
        # 8시간(28800초)마다 반복
        time.sleep(8 * 60 * 60)